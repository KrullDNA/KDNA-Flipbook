=== KDNA PDF Flipbook ===
Contributors: krulldna
Tags: pdf, flipbook, elementor, viewer, pdf.js
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.12
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A self-contained PDF-to-flipbook plugin with a fully styleable Elementor widget.

== Description ==

KDNA PDF Flipbook turns a PDF uploaded in the WordPress backend into a slick, responsive, page-flipping viewer on the front end. It is built for a pitching scenario. Each client gets their own page, built from a single custom post type entry, on which one or more PDF flipbooks are displayed, for example a welcome letter followed by a proposal.

The plugin is completely self-contained. It relies on no paid services and no third-party plugin, only two open-source JavaScript libraries that ship inside the plugin folder, PDF.js and StPageFlip. Nothing loads from an external server at runtime.

Key points:

* Configurable custom post type, named on first run.
* One entry per client, holding a repeater of flipbooks.
* Easy backend with the standard WordPress media uploader and drag to reorder.
* Elementor widget with a dynamic source and a matching dynamic tag.
* Live rendering in the browser with PDF.js, realistic page turns with StPageFlip.
* Crisp zoom that re-renders at a higher resolution.
* Per-page access code that gates the widget, with admin bypass.
* Every front-end control is a toggle and every element is styleable inside the widget.

== Installation ==

1. Go to Plugins, Add New, Upload Plugin and upload the ZIP.
2. Activate the plugin.
3. Complete the first-run setup to name your custom post type.
4. Adjust settings later under Settings, KDNA PDF Flipbook.

== Frequently Asked Questions ==

= Does it call any external servers? =

No. PDF.js and StPageFlip are bundled inside the plugin, and PDFs are served from your own media library.

= Do I need Elementor? =

The front-end viewer is delivered as an Elementor widget, so Elementor is required to place it on your client template.

== Changelog ==

= 1.0.12 =
* Made switching flipbooks more robust by rebuilding the viewer inside the stage, which fixes a blank viewer when clicking another flipbook. Added a kdnaFlipbookDebug() console helper.

= 1.0.11 =
* The toolbar can now sit above the flipbook as well as over the document or below the flipbook.

= 1.0.10 =
* Fixed switching flipbooks: clicking another flipbook in the sidebar now loads it, rather than showing a blank viewer. The viewer rebuilds on a clean element each time.
* Added sidebar icon hover and active colour controls.

= 1.0.9 =
* Added an Item background style control for the normal sidebar item state, to sit alongside the active and hover backgrounds.

= 1.0.8 =
* Removed the icon picker from the client entry, since sidebar icons are now set on the widget with Elementor's icon library. A toggle on the widget can use the first icon for all flipbooks.
* Fixed the active sidebar item so the item and icon colours apply to it, unless an active colour is set. Previously the active item stayed the old blue.
* Moved the reader hint styling into the Sidebar style section and made its divider styleable. Item dividers still need at least two flipbooks to show.

= 1.0.7 =
* Mouse wheel zoom is now off by default, so scrolling over the flipbook scrolls the page. It can be turned back on per widget or in the settings. The zoom buttons and pinch on mobile are unchanged.

= 1.0.6 =
* Sidebar icons can now be chosen from Elementor's own icon library on the widget, so Font Awesome and any registered icon packs are available. Widget icons apply to the flipbooks in order and override the icon set on the client entry.

= 1.0.5 =
* The toolbar placed below the flipbook now shrinks to the width of its buttons and centres, rather than filling the full width.

= 1.0.4 =
* Added a toolbar position option so the toolbar can sit below the flipbook instead of floating over the document.
* Added an editable reader hint, shown either at the top of the sidebar above the document list, or below the flipbook.

= 1.0.3 =
* Flipbook icons can now be chosen from a set of built-in icons or uploaded, including SVG.
* Added safe SVG uploads for users who can edit entries, with each SVG sanitised on upload to strip scripts and other active content.

= 1.0.2 =
* Fixed a fatal error when Elementor loaded the widget: the has_widget_inner_wrapper() method is now declared public to match Elementor.

= 1.0.1 =
* The custom post type is no longer created until it has been named on the setup screen, so no placeholder post type appears on activation.
* Added a persistent setup prompt so naming the post type is always offered, even if the activation redirect is blocked by the host.
* Registered the setup screen reliably under Settings and hid it from the menu.

= 1.0.0 =
* Stage 0: Plugin scaffold, configurable custom post type, first-run setup and settings screen.
* Stage 1: Flipbooks drag-to-reorder repeater and per-page access code, saved as post meta.
* Stage 2: Front-end viewer rendering PDFs with bundled PDF.js and flipping them with bundled StPageFlip, with desktop spread, single cover and mobile single-page swipe. Conditional asset loading.
* Stage 3: Front-end sidebar listing every flipbook with an icon and name, active highlight, and switching between flipbooks without a full page reload. Sidebar sits beside the viewer on desktop and above it on mobile.
* Stage 4: Crisp zoom that re-renders the current page with PDF.js at a higher resolution, with wheel or button zoom and drag to pan on desktop, pinch and drag on mobile, plus a fullscreen control. Adds the viewer toolbar.
* Stage 5: Full toolbar control suite, each able to be shown or hidden (arrows, thumbnails, zoom, fullscreen, table of contents, download, share, flip sound, deep-linking), plus fade-away or persistent toolbar behaviour and light, dark or custom chrome. Defaults read from settings for now.
* Stage 6: Per-page access code gate. A coded entry shows a code box in the viewer area, verified over admin-ajax with a nonce, then remembered for the session with a short-lived signed cookie. Admins and post editors bypass the gate, and pages with no code show the flipbooks straight away.
* Stage 7: Elementor widget built for Atomic markup, with the full Content tab (source, default view, control toggles, autoplay, toolbar behaviour, chrome theme, sidebar) and a registered dynamic tag that returns a client entry's flipbook PDF. The temporary content preview is retired in favour of the widget.
* Stage 8: Full Style tab. Every front-end element is styleable, scoped to the widget instance with Elementor's selector keyword: viewer, sidebar, toolbar and buttons, thumbnails, page numbers and captions, zoom and fullscreen, loading spinner and the access code box.
* Stage 9: Final polish. Confirmed conditional asset loading, the viewer rebinds on kdna:content-added, UK English with no em dashes, and consistent prefixes throughout. Packaged the plugin and added a wire-up guide.
